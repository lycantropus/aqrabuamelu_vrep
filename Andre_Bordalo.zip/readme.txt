1. software utilizado
 Ubuntu 14.04
 V-Rep Pro_EDU v3.3.2 64_linux

 2. Codigo Fonte
 O código fonte desovido é composto pelos ficheiros hexapodthreaded.lua e hexa_bodynonthreaded.lua
 O ficheiro hexabot.ttm contem o modelo do hexapod a ser importado no V-Rep.
 Os ficheiros hexaramp.ttt e hexastairs[1 a 5].ttt correspondem a varias cenas em que o robot foi testado

 3. Execuçao
 Para a simulaçao so projeto o modelo hexabott.ttm tem de ser importado no software V-Rep. Após a importaçao pode ser usado em qualquer cena simulada pelo software bastando arrastar a partir da lista de modelos. Alternativamente pode ser carregada uma cena com o robot ja inserido.

Modelo CAD cortesia de Lyall Randell (user Crazy eyes in Google3d Warehouse)


André Humberto Trigo de Bordalo Morais
Unidade Curricular Robótica do Mestrado Integrado em Engenharia Informática e Computação
https://sigarra.up.pt/feup/pt/ucurr_geral.ficha_uc_view?pv_ocorrencia_id=384987
Faculdade de Engenharia da Universidade do Porto
